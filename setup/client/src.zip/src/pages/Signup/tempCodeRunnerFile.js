dispatch(updateUserInfo({
                    email: email,
                    username: username
                }));