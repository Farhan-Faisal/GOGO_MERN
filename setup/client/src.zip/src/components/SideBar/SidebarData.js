export const SidebarData = [
  {
    title: "Requests",
    path: "/requests",
    cName: "nav-text",
  },
  {
    title: "Account",
    path: "/bio-page",
    cName: "nav-text",
  },
  {
    title: "Chats",
    path: "/chats",
    cName: "nav-text"
  },
  {
    title: "Logout",
    path: "/",
    cName: "nav-text",
  },
];
