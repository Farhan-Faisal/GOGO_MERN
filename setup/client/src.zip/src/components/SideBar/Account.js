import React from "react";
import configData from "../../config.json";
function Account(){
    return(
        <div className="page-title">
            <h1>ACCOUNT</h1>
        </div>
    );
}

export default Account;